import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import {
  Plus,
  Archive,
  Search,
  Settings,
  Sparkles,
  WifiOff,
  Wifi,
  Cloud,
  Download
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import AudioUploader from '@/components/stuart/AudioUploader';
import TranscriptViewer from '@/components/stuart/TranscriptViewer';
import FormalizationOutput from '@/components/stuart/FormalizationOutput';
import RunControls from '@/components/stuart/RunControls';
import SpeakerMapper from '@/components/stuart/SpeakerMapper';
import SessionCard from '@/components/stuart/SessionCard';
import SessionSearch from '@/components/stuart/SessionSearch';
import ChatInterface from '@/components/stuart/ChatInterface';
import ProcessingLog from '@/components/stuart/ProcessingLog';
import { PROFILES } from '@/components/stuart/ModeTemplateConfig';

export default function Stuart() {
  const [activeTab, setActiveTab] = useState('session');
  const [selectedSession, setSelectedSession] = useState(null);
  const [selectedFormalization, setSelectedFormalization] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [highlightedSegments, setHighlightedSegments] = useState([]);
  const [processingLogs, setProcessingLogs] = useState([]);
  
  const queryClient = useQueryClient();

  // Fetch sessions
  const { data: sessionsRaw = [], isLoading: sessionsLoading } = useQuery({
    queryKey: ['sessions'],
    queryFn: () => base44.entities.Session.list('-created_date', 50)
  });

  // Parse JSON strings in sessions
  const sessions = sessionsRaw.map(s => ({
    ...s,
    transcript_json: s.transcript_json_str ? JSON.parse(s.transcript_json_str) : [],
    speaker_map: s.speaker_map_str ? JSON.parse(s.speaker_map_str) : {}
  }));

  // Fetch formalizations for selected session
  const { data: formalizationsRaw = [] } = useQuery({
    queryKey: ['formalizations', selectedSession?.id],
    queryFn: () => base44.entities.Formalization.filter(
      { session_id: selectedSession?.id },
      '-created_date'
    ),
    enabled: !!selectedSession?.id
  });

  // Parse JSON strings in formalizations
  const formalizations = formalizationsRaw.map(f => ({
    ...f,
    output_json: f.output_json_str ? JSON.parse(f.output_json_str) : null,
    evidence_map: f.evidence_map_str ? JSON.parse(f.evidence_map_str) : [],
    processing_log: f.processing_log_str ? JSON.parse(f.processing_log_str) : []
  }));

  // Create session mutation
  const createSessionMutation = useMutation({
    mutationFn: (data) => base44.entities.Session.create(data),
    onSuccess: (newSession) => {
      queryClient.invalidateQueries({ queryKey: ['sessions'] });
      setSelectedSession(newSession);
      toast.success('Session created');
    }
  });

  // Update session mutation
  const updateSessionMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Session.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sessions'] });
      if (selectedSession) {
        queryClient.invalidateQueries({ queryKey: ['sessions'] });
      }
    }
  });

  // Create formalization mutation
  const createFormalizationMutation = useMutation({
    mutationFn: (data) => base44.entities.Formalization.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['formalizations', selectedSession?.id] });
    }
  });

  // Handle audio upload complete
  const handleUploadComplete = async ({ file_url, filename, duration_seconds }) => {
    const sessionData = {
      title: filename.replace(/\.[^/.]+$/, ''),
      audio_file_url: file_url,
      audio_filename: filename,
      duration_seconds,
      status: 'uploaded',
      profile: 'HYBRID'
    };

    await createSessionMutation.mutateAsync(sessionData);
  };

  // Handle transcription (simulated - would call backend in production)
  const handleTranscribe = async () => {
    if (!selectedSession) return;

    setIsProcessing(true);
    setProcessingLogs([
      { step: 'transcribe', status: 'running', message: 'Transcribing audio...', timestamp: new Date() }
    ]);

    try {
      // Simulate transcription (in production, use a speech-to-text service)
      // Note: Real transcription would require a separate speech-to-text integration
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a realistic transcript for a recorded audio session titled "${selectedSession.title}". 
Create 10-15 segments with natural conversation. Each segment needs:
- segment_id (seg_001, seg_002, etc.)
- start_time and end_time (in seconds, realistic timing)
- text (natural spoken content)
- speaker (SPEAKER_00, SPEAKER_01, etc. - use 2-4 different speakers)
- confidence (0.85-0.98 range)

Make it relevant to the filename: ${selectedSession.audio_filename}`,
        response_json_schema: {
          type: "object",
          properties: {
            segments: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  segment_id: { type: "string" },
                  start_time: { type: "number" },
                  end_time: { type: "number" },
                  text: { type: "string" },
                  speaker: { type: "string" },
                  confidence: { type: "number" }
                }
              }
            }
          }
        }
      });

      const transcript = response.segments || [];
      const transcriptText = transcript.map(seg => 
        `[${Math.floor(seg.start_time / 60)}:${String(Math.floor(seg.start_time % 60)).padStart(2, '0')}] ${seg.speaker}: ${seg.text}`
      ).join('\n');

      await updateSessionMutation.mutateAsync({
        id: selectedSession.id,
        data: {
          transcript_json_str: JSON.stringify(transcript),
          transcript_text: transcriptText,
          status: 'transcribed'
        }
      });

      setSelectedSession(prev => ({
        ...prev,
        transcript_json: transcript,
        transcript_text: transcriptText,
        status: 'transcribed'
      }));

      setProcessingLogs(prev => [
        ...prev.filter(l => l.step !== 'transcribe'),
        { step: 'transcribe', status: 'completed', message: `Transcribed ${transcript.length} segments`, timestamp: new Date() }
      ]);

      toast.success('Transcription complete');
    } catch (error) {
      setProcessingLogs(prev => [
        ...prev.filter(l => l.step !== 'transcribe'),
        { step: 'transcribe', status: 'failed', message: error.message, timestamp: new Date() }
      ]);
      toast.error('Transcription failed');
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle formalization run
  const handleRun = async (config) => {
    if (!selectedSession?.transcript_json?.length) {
      toast.error('No transcript available');
      return;
    }

    setIsProcessing(true);
    const runId = `run_${Date.now()}`;
    
    setProcessingLogs([
      { step: 'formalize', status: 'running', message: 'Generating formalization...', timestamp: new Date() }
    ]);

    try {
      const transcriptText = selectedSession.transcript_json
        .map(seg => `[${seg.segment_id}] ${seg.speaker || 'Unknown'}: ${seg.text}`)
        .join('\n');

      const retentionPrompt = {
        LOW: 'Be extremely concise. Only include the most critical points.',
        MED: 'Provide a balanced summary with key details.',
        HIGH: 'Include detailed information and context.',
        NEAR_VERBATIM: 'Preserve original phrasing as much as possible.'
      }[config.retention_level];

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are Stuart, an evidence-backed meeting intelligence system.

TRANSCRIPT:
${transcriptText}

TASK: Generate a ${config.mode.replace('_', ' ')} formalization using the "${config.template}" template.

CRITICAL RULES:
1. NEVER invent facts, decisions, or action items not in the transcript
2. Every claim must be traceable to specific segment IDs
3. ${retentionPrompt}

Output format:
1. output_json: Structured data based on template fields
2. output_markdown: Human-readable formatted output
3. evidence_map: Array linking each claim to segment_ids and timestamps

Be thorough but strictly evidence-based.`,
        response_json_schema: {
          type: "object",
          properties: {
            output_json: { type: "object" },
            output_markdown: { type: "string" },
            evidence_map: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  claim: { type: "string" },
                  claim_type: { type: "string" },
                  segment_ids: { type: "array", items: { type: "string" } },
                  timestamp_range: { type: "string" }
                }
              }
            }
          }
        }
      });

      const formalizationData = {
        session_id: selectedSession.id,
        run_id: runId,
        mode: config.mode,
        template: config.template,
        retention_level: config.retention_level,
        status: 'completed',
        output_json_str: JSON.stringify(response.output_json),
        output_markdown: response.output_markdown,
        evidence_map_str: JSON.stringify(response.evidence_map || []),
        data_left_machine: config.profile !== 'LOCAL_ONLY',
        adapters_used: ['InvokeLLM'],
        processing_log_str: JSON.stringify(processingLogs)
      };

      // Also keep parsed versions for display
      const displayFormalization = {
        ...formalizationData,
        output_json: response.output_json,
        evidence_map: response.evidence_map || [],
        processing_log: processingLogs
      };

      await createFormalizationMutation.mutateAsync(formalizationData);
      setSelectedFormalization(displayFormalization);

      await updateSessionMutation.mutateAsync({
        id: selectedSession.id,
        data: { status: 'formalized' }
      });

      setSelectedSession(prev => ({ ...prev, status: 'formalized' }));

      setProcessingLogs(prev => [
        ...prev.filter(l => l.step !== 'formalize'),
        { 
          step: 'formalize', 
          status: 'completed', 
          message: 'Formalization complete',
          timestamp: new Date(),
          data_sent_externally: config.profile !== 'LOCAL_ONLY'
        }
      ]);

      toast.success('Formalization complete');
    } catch (error) {
      setProcessingLogs(prev => [
        ...prev.filter(l => l.step !== 'formalize'),
        { step: 'formalize', status: 'failed', message: error.message, timestamp: new Date() }
      ]);
      
      await createFormalizationMutation.mutateAsync({
        session_id: selectedSession.id,
        run_id: runId,
        mode: config.mode,
        template: config.template,
        retention_level: config.retention_level,
        status: 'failed',
        error_message: error.message
      });

      toast.error('Formalization failed');
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle speaker map update
  const handleSpeakerMapUpdate = async (speakerMap) => {
    if (!selectedSession) return;

    await updateSessionMutation.mutateAsync({
      id: selectedSession.id,
      data: { speaker_map_str: JSON.stringify(speakerMap) }
    });

    setSelectedSession(prev => ({ ...prev, speaker_map: speakerMap }));
    toast.success('Speaker mapping saved');
  };

  // Handle chat message
  const handleChatMessage = async (message, onResponse) => {
    if (!selectedSession?.transcript_json?.length) {
      onResponse("Please upload and transcribe an audio file first.");
      return;
    }

    setIsProcessing(true);
    try {
      const transcriptContext = selectedSession.transcript_json
        .map(seg => `[${seg.segment_id}] ${seg.speaker || 'Unknown'}: ${seg.text}`)
        .join('\n');

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are Stuart, an evidence-backed meeting intelligence assistant.

TRANSCRIPT:
${transcriptContext}

USER QUESTION: ${message}

RULES:
- Only answer based on what's in the transcript
- Cite segment IDs when referencing specific content
- If the information isn't in the transcript, say so clearly
- Be helpful but never invent information`,
      });

      onResponse(response);
    } catch (error) {
      onResponse("I encountered an error processing your request. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  // Export session as ZIP (simulated)
  const handleExportZip = () => {
    toast.info('Export functionality would package all session artifacts into a ZIP file');
  };

  const ProfileIcon = selectedSession?.profile === 'LOCAL_ONLY' ? WifiOff : 
                      selectedSession?.profile === 'CLOUD' ? Cloud : Wifi;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-slate-700 to-slate-900 flex items-center justify-center">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-xl text-slate-800">Stuart</h1>
                <p className="text-xs text-slate-500">Voice Intelligence System</p>
              </div>
            </div>
            
            {selectedSession && (
              <div className="flex items-center gap-2">
                <Badge className={`text-xs ${PROFILES[selectedSession.profile]?.color || 'bg-slate-500'} text-white`}>
                  <ProfileIcon className="h-3 w-3 mr-1" />
                  {PROFILES[selectedSession.profile]?.label || 'Hybrid'}
                </Badge>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-12 gap-6">
          {/* Sidebar - Session List */}
          <aside className="col-span-12 lg:col-span-3">
            <div className="sticky top-24 space-y-4">
              <button 
                className="w-full relative group overflow-hidden rounded-lg"
                onClick={() => {
                  setSelectedSession(null);
                  setSelectedFormalization(null);
                }}
              >
                <div className="relative px-6 py-3 bg-gradient-to-b from-amber-500 via-amber-600 to-amber-700 shadow-lg border-2 border-amber-400/60">
                  <div className="absolute inset-0 bg-gradient-to-b from-amber-300/40 to-transparent" />
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,255,255,0.3),transparent_60%)]" />
                  <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-200 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-t from-amber-900/60 to-transparent" />
                  
                  <div className="relative flex items-center justify-center gap-2 font-bold text-base text-amber-50 drop-shadow-[0_2px_2px_rgba(0,0,0,0.5)] group-hover:scale-105 transition-transform">
                    <Plus className="h-5 w-5" />
                    <span className="tracking-wide">New Session</span>
                  </div>
                </div>
                
                <div className="absolute inset-0 shadow-[inset_0_0_12px_rgba(0,0,0,0.3)] rounded-lg pointer-events-none" />
              </button>

              <Tabs defaultValue="recent" className="w-full">
                <TabsList className="w-full bg-slate-100">
                  <TabsTrigger value="recent" className="flex-1">
                    <Archive className="h-4 w-4 mr-1.5" />
                    Recent
                  </TabsTrigger>
                  <TabsTrigger value="search" className="flex-1">
                    <Search className="h-4 w-4 mr-1.5" />
                    Search
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="recent" className="mt-3">
                  <ScrollArea className="h-[calc(100vh-280px)]">
                    <div className="space-y-2 pr-2">
                      {sessionsLoading ? (
                        <p className="text-sm text-slate-400 text-center py-4">Loading...</p>
                      ) : sessions.length === 0 ? (
                        <p className="text-sm text-slate-400 text-center py-4">No sessions yet</p>
                      ) : (
                        sessions.map(session => (
                          <SessionCard
                            key={session.id}
                            session={session}
                            isSelected={selectedSession?.id === session.id}
                            onClick={(s) => {
                              setSelectedSession(s);
                              setSelectedFormalization(null);
                            }}
                          />
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="search" className="mt-3">
                  <SessionSearch
                    sessions={sessions}
                    onSessionSelect={(s) => {
                      setSelectedSession(s);
                      setActiveTab('session');
                    }}
                    onJumpToTimestamp={(session, timestamp) => {
                      setSelectedSession(session);
                      setActiveTab('session');
                      // Could implement scroll-to-segment here
                    }}
                  />
                </TabsContent>
              </Tabs>
            </div>
          </aside>

          {/* Main Content */}
          <div className="col-span-12 lg:col-span-9">
            {!selectedSession ? (
              /* New Session View */
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="text-center py-8">
                  <h2 className="text-2xl font-semibold text-slate-800 mb-2">
                    Start a New Session
                  </h2>
                  <p className="text-slate-500">
                    Upload an audio recording to begin extracting insights
                  </p>
                </div>

                <AudioUploader onUploadComplete={handleUploadComplete} />
              </motion.div>
            ) : (
              /* Session View */
              <AnimatePresence mode="wait">
                <motion.div
                  key={selectedSession.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  {/* Session Header */}
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-xl font-semibold text-slate-800">
                        {selectedSession.title}
                      </h2>
                      <p className="text-sm text-slate-500">
                        {selectedSession.audio_filename}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {selectedSession.status === 'uploaded' && (
                        <Button onClick={handleTranscribe} disabled={isProcessing}>
                          Transcribe
                        </Button>
                      )}
                      <Button variant="outline" onClick={handleExportZip}>
                        <Download className="h-4 w-4 mr-1.5" />
                        Export ZIP
                      </Button>
                    </div>
                  </div>

                  {/* Content Tabs */}
                  <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList className="bg-slate-100">
                      <TabsTrigger value="session">Session</TabsTrigger>
                      <TabsTrigger value="chat">Chat</TabsTrigger>
                      <TabsTrigger value="formalizations">
                        Outputs ({formalizations.length})
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="session" className="mt-6">
                      <div className="grid grid-cols-12 gap-6">
                        {/* Left Column - Transcript & Speakers */}
                        <div className="col-span-12 xl:col-span-7 space-y-6">
                          <TranscriptViewer
                            transcript={selectedSession.transcript_json}
                            speakerMap={selectedSession.speaker_map}
                            highlightedSegments={highlightedSegments}
                            onSegmentClick={(seg) => setHighlightedSegments([seg.segment_id])}
                          />

                          {selectedSession.transcript_json?.length > 0 && 
                           selectedSession.transcript_json.some(s => s.speaker) && (
                            <SpeakerMapper
                              transcript={selectedSession.transcript_json}
                              speakerMap={selectedSession.speaker_map || {}}
                              onSpeakerMapUpdate={handleSpeakerMapUpdate}
                            />
                          )}
                        </div>

                        {/* Right Column - Controls & Output */}
                        <div className="col-span-12 xl:col-span-5 space-y-6">
                          <RunControls
                            session={selectedSession}
                            onRun={handleRun}
                            isProcessing={isProcessing}
                          />

                          {processingLogs.length > 0 && (
                            <ProcessingLog logs={processingLogs} />
                          )}

                          <FormalizationOutput
                            formalization={selectedFormalization || formalizations[0]}
                            onHighlightSegments={setHighlightedSegments}
                          />
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="chat" className="mt-6">
                      <ChatInterface
                        session={selectedSession}
                        onSendMessage={handleChatMessage}
                        isProcessing={isProcessing}
                        className="h-[600px]"
                      />
                    </TabsContent>

                    <TabsContent value="formalizations" className="mt-6">
                      <div className="grid gap-4">
                        {formalizations.length === 0 ? (
                          <div className="text-center py-12 text-slate-500">
                            No formalizations yet. Run one from the Session tab.
                          </div>
                        ) : (
                          formalizations.map(f => (
                            <FormalizationOutput
                              key={f.id}
                              formalization={f}
                              onHighlightSegments={setHighlightedSegments}
                            />
                          ))
                        )}
                      </div>
                    </TabsContent>
                  </Tabs>
                </motion.div>
              </AnimatePresence>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}