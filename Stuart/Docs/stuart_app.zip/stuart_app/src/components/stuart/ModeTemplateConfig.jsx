// Mode and Template configuration
export const MODES = {
  meeting_minutes: {
    label: "Meeting Minutes",
    description: "Extract decisions, action items, and key points from meetings",
    templates: {
      standard: {
        label: "Standard Meeting",
        fields: ["attendees", "agenda", "decisions", "action_items", "follow_ups"]
      },
      standup: {
        label: "Daily Standup",
        fields: ["yesterday", "today", "blockers"]
      },
      retrospective: {
        label: "Retrospective",
        fields: ["went_well", "to_improve", "action_items"]
      },
      one_on_one: {
        label: "1:1 Meeting",
        fields: ["topics_discussed", "feedback", "goals", "action_items"]
      }
    }
  },
  journal: {
    label: "Journal Entry",
    description: "Personal reflection and thought capture",
    templates: {
      daily: {
        label: "Daily Journal",
        fields: ["summary", "reflections", "gratitude", "goals"]
      },
      brainstorm: {
        label: "Brainstorm Session",
        fields: ["ideas", "connections", "next_steps"]
      }
    }
  },
  incident_report: {
    label: "Incident Report",
    description: "Document incidents with timeline and evidence",
    templates: {
      standard: {
        label: "Standard Incident",
        fields: ["summary", "timeline", "impact", "root_cause", "resolution", "prevention"]
      },
      security: {
        label: "Security Incident",
        fields: ["summary", "timeline", "affected_systems", "data_exposure", "response_actions", "remediation"]
      }
    }
  },
  general_query: {
    label: "General Query",
    description: "Ask questions about the transcript",
    templates: {
      summary: {
        label: "Summary",
        fields: ["key_points", "themes"]
      },
      extraction: {
        label: "Data Extraction",
        fields: ["extracted_data"]
      }
    }
  }
};

export const RETENTION_LEVELS = {
  LOW: {
    label: "Low",
    description: "Highly condensed, key points only"
  },
  MED: {
    label: "Medium",
    description: "Balanced summary with context"
  },
  HIGH: {
    label: "High",
    description: "Detailed preservation of content"
  },
  NEAR_VERBATIM: {
    label: "Near Verbatim",
    description: "Preserve original phrasing as much as possible"
  }
};

export const PROFILES = {
  LOCAL_ONLY: {
    label: "Local Only",
    description: "No data leaves your machine",
    color: "bg-green-500"
  },
  HYBRID: {
    label: "Hybrid",
    description: "Remote processing with confirmation",
    color: "bg-yellow-500"
  },
  CLOUD: {
    label: "Cloud",
    description: "Remote-first processing",
    color: "bg-blue-500"
  }
};

export function getTemplatesForMode(mode) {
  return MODES[mode]?.templates || {};
}

export function isValidModeTemplate(mode, template) {
  return MODES[mode]?.templates?.[template] !== undefined;
}