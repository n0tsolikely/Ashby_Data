import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  FileText, 
  Code, 
  Link2, 
  Download, 
  Printer,
  ChevronRight,
  AlertTriangle
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function FormalizationOutput({ 
  formalization, 
  onHighlightSegments,
  onDownloadPdf,
  className 
}) {
  const [activeTab, setActiveTab] = useState("formatted");

  if (!formalization) {
    return (
      <Card className={cn("border-slate-200", className)}>
        <CardContent className="py-12 text-center">
          <FileText className="h-12 w-12 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500">No formalization generated yet</p>
          <p className="text-sm text-slate-400 mt-1">
            Select a mode and template, then click "Run" to generate
          </p>
        </CardContent>
      </Card>
    );
  }

  const { output_json, output_markdown, evidence_map, status, mode, template, retention_level } = formalization;

  return (
    <Card className={cn("border-slate-200", className)}>
      <CardHeader className="pb-3 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CardTitle className="text-base font-medium text-slate-700">
              Formalization Output
            </CardTitle>
            <Badge variant="secondary" className="capitalize">
              {mode?.replace('_', ' ')}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {template}
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            {formalization.pdf_url && (
              <>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => window.open(formalization.pdf_url, '_blank')}
                >
                  <Printer className="h-4 w-4 mr-1.5" />
                  Print
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={onDownloadPdf}
                >
                  <Download className="h-4 w-4 mr-1.5" />
                  PDF
                </Button>
              </>
            )}
          </div>
        </div>
        {status === 'partial' && (
          <div className="flex items-center gap-2 mt-2 p-2 bg-amber-50 rounded-lg">
            <AlertTriangle className="h-4 w-4 text-amber-500" />
            <span className="text-sm text-amber-700">
              Partial output - some sections may be incomplete
            </span>
          </div>
        )}
      </CardHeader>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="px-4 pt-3 border-b border-slate-100">
          <TabsList className="bg-slate-100/50">
            <TabsTrigger value="formatted" className="text-sm">
              <FileText className="h-4 w-4 mr-1.5" />
              Formatted
            </TabsTrigger>
            <TabsTrigger value="json" className="text-sm">
              <Code className="h-4 w-4 mr-1.5" />
              JSON
            </TabsTrigger>
            <TabsTrigger value="evidence" className="text-sm">
              <Link2 className="h-4 w-4 mr-1.5" />
              Evidence Map
            </TabsTrigger>
          </TabsList>
        </div>

        <ScrollArea className="h-[500px]">
          <TabsContent value="formatted" className="p-4 mt-0">
            {output_markdown ? (
              <div className="prose prose-sm prose-slate max-w-none">
                <ReactMarkdown>{output_markdown}</ReactMarkdown>
              </div>
            ) : (
              <p className="text-slate-400 italic">No formatted output available</p>
            )}
          </TabsContent>

          <TabsContent value="json" className="p-4 mt-0">
            {output_json ? (
              <pre className="p-4 bg-slate-900 text-slate-100 rounded-lg text-xs overflow-x-auto">
                {JSON.stringify(output_json, null, 2)}
              </pre>
            ) : (
              <p className="text-slate-400 italic">No JSON output available</p>
            )}
          </TabsContent>

          <TabsContent value="evidence" className="p-4 mt-0">
            {evidence_map && evidence_map.length > 0 ? (
              <div className="space-y-3">
                {evidence_map.map((evidence, idx) => (
                  <div 
                    key={idx} 
                    className="p-3 border border-slate-200 rounded-lg hover:border-slate-300 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="text-sm font-medium text-slate-700">
                          {evidence.claim}
                        </p>
                        <p className="text-xs text-slate-500 mt-1">
                          {evidence.claim_type && (
                            <Badge variant="outline" className="mr-2 text-xs">
                              {evidence.claim_type}
                            </Badge>
                          )}
                          Segments: {evidence.segment_ids?.join(', ') || 'N/A'}
                        </p>
                        {evidence.timestamp_range && (
                          <p className="text-xs text-slate-400 mt-0.5">
                            Time: {evidence.timestamp_range}
                          </p>
                        )}
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onHighlightSegments?.(evidence.segment_ids || [])}
                        className="text-slate-500"
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Link2 className="h-10 w-10 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-400">No evidence mapping available</p>
              </div>
            )}
          </TabsContent>
        </ScrollArea>
      </Tabs>

      <div className="px-4 py-3 border-t border-slate-100 bg-slate-50/50">
        <div className="flex items-center justify-between text-xs text-slate-500">
          <span>Retention: {retention_level}</span>
          {formalization.data_left_machine && (
            <Badge variant="outline" className="text-amber-600 border-amber-300">
              Data sent externally
            </Badge>
          )}
        </div>
      </div>
    </Card>
  );
}